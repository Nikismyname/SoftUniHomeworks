﻿
public class MachineGun : Ammunition
{
    private const double Weight = 10.6;

    public MachineGun(string name)
        : base(name, Weight)
    {
    }
}