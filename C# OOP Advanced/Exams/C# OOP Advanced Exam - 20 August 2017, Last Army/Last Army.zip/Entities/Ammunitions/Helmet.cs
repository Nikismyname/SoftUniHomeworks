﻿public class Helmet : Ammunition
{
    private const double Weight = 2.3;

    public Helmet(string name)
        : base(name, Weight)
    {
    }
}